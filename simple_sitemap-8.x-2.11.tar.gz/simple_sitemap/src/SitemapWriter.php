<?php

namespace Drupal\simple_sitemap;

use XMLWriter;

/**
 * Class SitemapWriter
 * @package Drupal\simple_sitemap
 */
class SitemapWriter extends XMLWriter {

}
